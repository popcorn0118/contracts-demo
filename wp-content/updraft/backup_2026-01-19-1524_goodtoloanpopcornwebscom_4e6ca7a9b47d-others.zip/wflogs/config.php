<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:6:{s:9:"wafStatus";s:13:"learning-mode";s:30:"learningModeGracePeriodEnabled";i:1;s:23:"learningModeGracePeriod";i:1766922886;s:7:"authKey";s:64:"b*y[->i~{Q?Wj]qwc.=;ntR]%{D1z.16<|]8GWG=`gt1=aqME6.=g[^m~R5~e60(";s:7:"version";s:5:"1.1.0";s:11:"wafDisabled";b:1;}